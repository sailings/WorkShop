#! /bin/bash

dotnet publish src/BootstrapBlazor.WebConsole -c Release
