#! /bin/bash

dotnet watch --project src/BootstrapBlazor.WebConsole run
