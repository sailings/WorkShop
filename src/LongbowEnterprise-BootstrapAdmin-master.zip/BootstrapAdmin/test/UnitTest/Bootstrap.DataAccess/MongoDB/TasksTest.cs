﻿using Xunit;

namespace Bootstrap.DataAccess.MongoDB
{
    [Collection("MongoContext")]
    public class TasksTest : DataAccess.TasksTest
    {

    }
}
