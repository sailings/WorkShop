﻿using Xunit;

namespace Bootstrap.DataAccess.MongoDB
{
    [Collection("MongoContext")]
    public class RolesTest : DataAccess.RolesTest
    {

    }
}
