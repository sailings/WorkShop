﻿using Xunit;

namespace Bootstrap.DataAccess.MongoDB
{
    [Collection("MongoContext")]
    public class LogsTest : DataAccess.LogsTest
    {

    }
}
