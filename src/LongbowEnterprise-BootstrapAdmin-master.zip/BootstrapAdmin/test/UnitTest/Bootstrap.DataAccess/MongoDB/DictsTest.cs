﻿using Xunit;

namespace Bootstrap.DataAccess.MongoDB
{
    [Collection("MongoContext")]
    public class DictsTest : DataAccess.DictsTest
    {

    }
}
