﻿using Xunit;

namespace Bootstrap.DataAccess.MongoDB
{
    [Collection("MongoContext")]
    public class AppTest : DataAccess.AppTest
    {

    }
}
