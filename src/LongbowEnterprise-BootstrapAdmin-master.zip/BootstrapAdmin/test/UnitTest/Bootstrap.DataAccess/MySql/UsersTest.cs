﻿using Xunit;

namespace Bootstrap.DataAccess.MySql
{
    [Collection("MySqlContext")]
    public class UsersTest : DataAccess.UsersTest
    {

    }
}
