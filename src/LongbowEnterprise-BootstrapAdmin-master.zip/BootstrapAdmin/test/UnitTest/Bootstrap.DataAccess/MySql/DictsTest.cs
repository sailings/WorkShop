﻿using Xunit;

namespace Bootstrap.DataAccess.MySql
{
    [Collection("MySqlContext")]
    public class DictsTest : DataAccess.DictsTest
    {

    }
}
