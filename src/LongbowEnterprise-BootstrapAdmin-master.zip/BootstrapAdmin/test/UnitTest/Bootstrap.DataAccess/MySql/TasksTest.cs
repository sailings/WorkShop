﻿using Xunit;

namespace Bootstrap.DataAccess.MySql
{
    [Collection("MySqlContext")]
    public class TasksTest : DataAccess.TasksTest
    {

    }
}
