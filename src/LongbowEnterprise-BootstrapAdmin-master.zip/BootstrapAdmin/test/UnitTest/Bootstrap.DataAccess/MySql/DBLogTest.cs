﻿using Xunit;

namespace Bootstrap.DataAccess.MySql
{
    [Collection("MySqlContext")]
    public class DBLogTest : DataAccess.DBLogTest
    {

    }
}
