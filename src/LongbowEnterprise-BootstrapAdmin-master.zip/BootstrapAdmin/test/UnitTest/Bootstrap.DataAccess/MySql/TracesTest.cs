﻿using Xunit;

namespace Bootstrap.DataAccess.MySql
{
    [Collection("MySqlContext")]
    public class TracesTest : DataAccess.TracesTest
    {

    }
}
