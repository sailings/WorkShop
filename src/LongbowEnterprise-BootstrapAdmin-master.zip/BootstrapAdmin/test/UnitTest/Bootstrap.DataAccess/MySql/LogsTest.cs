﻿using Xunit;

namespace Bootstrap.DataAccess.MySql
{
    [Collection("MySqlContext")]
    public class LogsTest : DataAccess.LogsTest
    {

    }
}
