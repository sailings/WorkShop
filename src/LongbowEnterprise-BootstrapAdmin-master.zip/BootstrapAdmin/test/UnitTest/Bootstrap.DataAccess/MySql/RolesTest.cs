﻿using Xunit;

namespace Bootstrap.DataAccess.MySql
{
    [Collection("MySqlContext")]
    public class RolesTest : DataAccess.RolesTest
    {

    }
}
