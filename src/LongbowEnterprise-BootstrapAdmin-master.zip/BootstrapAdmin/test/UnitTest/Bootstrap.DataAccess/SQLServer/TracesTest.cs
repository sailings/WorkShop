﻿using Xunit;

namespace Bootstrap.DataAccess.SQLServer
{
    [CollectionDefinition("SQLServerContext")]
    public class TracesTest : DataAccess.TracesTest
    {

    }
}
