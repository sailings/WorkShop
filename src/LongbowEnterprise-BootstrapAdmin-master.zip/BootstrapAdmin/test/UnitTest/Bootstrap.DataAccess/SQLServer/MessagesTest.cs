﻿using Xunit;

namespace Bootstrap.DataAccess.SQLServer
{
    [CollectionDefinition("SQLServerContext")]
    public class MessagesTest : DataAccess.MessagesTest
    {

    }
}
