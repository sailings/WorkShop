﻿using Xunit;

namespace Bootstrap.DataAccess.SQLServer
{
    [CollectionDefinition("SQLServerContext")]
    public class LogsTest : DataAccess.LogsTest
    {

    }
}
