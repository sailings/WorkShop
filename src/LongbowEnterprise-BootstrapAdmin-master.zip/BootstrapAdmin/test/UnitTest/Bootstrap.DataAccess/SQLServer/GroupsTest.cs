﻿using Xunit;

namespace Bootstrap.DataAccess.SQLServer
{
    [CollectionDefinition("SQLServerContext")]
    public class GroupsTest : DataAccess.GroupsTest
    {

    }
}
