﻿using Xunit;

namespace Bootstrap.DataAccess.SQLServer
{
    [CollectionDefinition("SQLServerContext")]
    public class RolesTest : DataAccess.RolesTest
    {

    }
}
