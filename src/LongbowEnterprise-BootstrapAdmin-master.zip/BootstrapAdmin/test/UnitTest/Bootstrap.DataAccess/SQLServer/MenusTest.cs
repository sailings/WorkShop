﻿using Xunit;

namespace Bootstrap.DataAccess.SQLServer
{
    [CollectionDefinition("SQLServerContext")]
    public class MenusTest : DataAccess.MenusTest
    {

    }
}
