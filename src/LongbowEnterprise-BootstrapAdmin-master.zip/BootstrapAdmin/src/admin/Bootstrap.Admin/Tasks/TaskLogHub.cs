﻿using Longbow.Web.SignalR;

namespace Microsoft.AspNetCore.SignalR
{
    /// <summary>
    /// 后台任务消息Hub
    /// </summary>
    public class TaskLogHub : SignalRHub
    {

    }
}
