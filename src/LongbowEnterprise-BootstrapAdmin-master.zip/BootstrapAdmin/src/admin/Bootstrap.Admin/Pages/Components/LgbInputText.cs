using Bootstrap.Admin.Pages.Shared;

namespace Bootstrap.Admin.Pages.Components
{
    /// <summary>
    /// LgbInputText 组件
    /// </summary>
    public class LgbInputText : LgbInput<string>
    {

    }
}
