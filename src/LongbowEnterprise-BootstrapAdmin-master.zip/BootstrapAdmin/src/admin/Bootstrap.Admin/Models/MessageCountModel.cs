﻿namespace Bootstrap.Admin.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class MessageCountModel
    {
        /// <summary>
        /// 
        /// </summary>
        public int InboxCount { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int SendmailCount { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int MarkCount { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int TrashCount { get; set; }
    }
}