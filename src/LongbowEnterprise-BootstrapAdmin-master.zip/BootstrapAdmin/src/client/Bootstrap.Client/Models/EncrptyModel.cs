using Microsoft.AspNetCore.Mvc;

namespace Bootstrap.Client.Models
{
    /// <summary>
    /// Encrpty Model
    /// </summary>
    public class EncrptyModel : NavigatorBarModel
    {
        /// <summary>
        /// 构造函数
        /// </summary>
        public EncrptyModel(ControllerBase controller) : base(controller)
        {

        }
    }
}
