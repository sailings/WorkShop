﻿Roles = [
    {
        "_id": ObjectId("1bd7b8445fa31256f77e4b91"),
        "RoleName": "Administrators",
        "Description": "系统管理员",
        "Menus": [],
        "Apps": []
    },
    {
        "RoleName": "Default",
        "Description": "默认用户，可访问前台页面",
        "Menus": [],
        "Apps": ["BA", "Demo"]
    }
];