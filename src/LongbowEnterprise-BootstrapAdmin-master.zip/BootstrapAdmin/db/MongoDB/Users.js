﻿Users = [
    {
        "UserName": "Admin",
        "Password": "yvWGJ6JqABFIxCZJy1czv5xR9CPI3KWMmevWn3CfGcc=",
        "PassSalt": "Zs6VGITmaveCFGBPKmNH+YM8DTyMi6D8cGKaNEyfDuaaMvTe",
        "DisplayName": "Administrator",
        "RegisterTime": ISODate("2018-09-09T06:06:20.130+0000"),
        "ApprovedTime": ISODate("2018-09-09T06:06:20.130+0000"),
        "ApprovedBy": "system",
        "Description": "系统默认创建",
        "Icon": "default.jpg",
        "Css": null,
        "App": null,
        "IsReset": 0,
        "Roles": ["1bd7b8445fa31256f77e4b91"],
        "Groups": []
    },
    {
        "UserName": "User",
        "Password": "2v9os69yRQ2j3y3/J+CCd4bG3mlu/fn+wGpZBzFlhOg=",
        "PassSalt": "djT5LiGxwS1l8aDGP0f92v06fbA5BhOcwRGkv5ENIHFtzc1b",
        "DisplayName": "测试用户",
        "RegisterTime": ISODate("2018-09-13T13:27:12.957+0000"),
        "ApprovedTime": ISODate("2018-09-13T13:27:12.957+0000"),
        "ApprovedBy": "Admin",
        "Description": "管理员Admin创建用户",
        "Icon": "default.jpg",
        "Css": null,
        "App": null,
        "IsReset": 0,
        "Groups": [],
        "Roles": []
    }
];
