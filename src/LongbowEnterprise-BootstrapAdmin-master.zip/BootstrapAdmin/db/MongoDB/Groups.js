﻿Groups = [
    {
        "GroupCode": "001",
        "GroupName": "Admin",
        "Description": "系统默认组",
        "Roles": []
    }
];
