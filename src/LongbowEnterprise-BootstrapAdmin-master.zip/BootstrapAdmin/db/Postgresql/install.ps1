# init postgresql data
