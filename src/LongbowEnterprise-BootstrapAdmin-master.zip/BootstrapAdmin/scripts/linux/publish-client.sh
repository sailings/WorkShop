#! /bin/bash

dotnet publish src/client/Bootstrap.Client -c Release
