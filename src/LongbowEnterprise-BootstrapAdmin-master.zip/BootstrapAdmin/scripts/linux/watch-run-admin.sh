#! /bin/bash

dotnet watch --project ./src/admin/Bootstrap.Admin run
