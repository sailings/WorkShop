#! /bin/bash

dotnet watch --project ./src/client/Bootstrap.Client run
