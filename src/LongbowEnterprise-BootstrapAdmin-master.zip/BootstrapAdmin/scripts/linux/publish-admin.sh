#! /bin/bash

dotnet publish src/admin/Bootstrap.Admin -c Release
