﻿#! /bin/bash

cp commit_msg_template.txt "../../.git/commit_msg_template1.txt"
